package com.cognizant.entity;
import java.io.Serializable;

import javax.persistence.Entity;
import javax.persistence.GeneratedValue;
import javax.persistence.GenerationType;
import javax.persistence.Id;
@Entity
public class Technologies  implements Serializable{
	/**
	 * 
	 */
	private static final long serialVersionUID = 3524503380930162795L;
	@Id
	@GeneratedValue(strategy = GenerationType.AUTO)
	private long technologyId;
	private  String technologiesName;
	public long getTechnologyId() {
		return technologyId;
	}
	public void setTechnologyId(long technologyId) {
		this.technologyId = technologyId;
	}
	public String getTechnologiesName() {
		return technologiesName;
	}
	public void setTechnologiesName(String technologiesName) {
		this.technologiesName = technologiesName;
	}
	@Override
	public String toString() {
		return "Technologies [technologyId=" + technologyId + ", technologiesName=" + technologiesName + "]";
	}
	
	
	
}
