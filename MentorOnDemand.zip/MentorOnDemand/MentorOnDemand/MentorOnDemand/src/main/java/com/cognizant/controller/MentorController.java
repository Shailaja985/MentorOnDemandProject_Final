package com.cognizant.controller;

import java.sql.Date;
import java.util.Properties;

import javax.mail.Message;
import javax.mail.MessagingException;
import javax.mail.PasswordAuthentication;
import javax.mail.Session;
import javax.mail.Transport;
import javax.mail.internet.InternetAddress;
import javax.mail.internet.MimeMessage;
import javax.servlet.ServletException;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.web.bind.annotation.CrossOrigin;
import org.springframework.web.bind.annotation.RequestBody;
import org.springframework.web.bind.annotation.RequestMapping;
import org.springframework.web.bind.annotation.RequestMethod;
import org.springframework.web.bind.annotation.RequestParam;
import org.springframework.web.bind.annotation.RestController;
import com.cognizant.entity.Mentor;
import com.cognizant.entity.User;
import com.cognizant.service.MentorService;
import io.jsonwebtoken.Jwts;
import io.jsonwebtoken.SignatureAlgorithm;

@CrossOrigin(origins = "http://localhost", maxAge = 3600)
@RestController
@RequestMapping("/mentor")
public class MentorController {
	@Autowired
	private MentorService mentorService;

	@RequestMapping(value = "/register", method = RequestMethod.POST)
	public Mentor registerMentor(@RequestBody Mentor mentor) 
	{
			Mentor mentor1= new Mentor();
			mentor1=mentorService.save(mentor);
	      	Properties propvls = new Properties();
	        final String sendrmailid = "stockmarketcharting@gmail.com";
	        final String pwd = "raes17081996";
	        String smtphost = "smtp.gmail.com";
	        propvls.put("mail.smtp.auth", "true");
	        propvls.put("mail.smtp.starttls.enable", "true");
	        propvls.put("mail.smtp.host", smtphost);
	        propvls.put("mail.smtp.port", "25");
	        Session sessionobj = Session.getInstance(propvls, new javax.mail.Authenticator() 
	        {
	        	protected PasswordAuthentication getPasswordAuthentication() 
	        	{
	            System.out.println("In session");
	            return new PasswordAuthentication(sendrmailid, pwd);
	        	}
	        });
	        try
	        {
	           // Create MimeMessage object & set values
	           Message messageobj = new MimeMessage(sessionobj);
	           messageobj.setFrom(new InternetAddress(sendrmailid));
	           messageobj.setRecipients(Message.RecipientType.TO, InternetAddress.parse(mentor1.getEmail()));
	           messageobj.setSubject("Congrats on registration to MentorOnDemand Happy Trading!");
	           messageobj.setText("You are successfully registered to the MentorOnDemand with the following details"+"\n userId: "+mentor1.getMentorId()+"\n userName: "+mentor1.getUsername()+"\n Password: "+mentor1.getPassword()+"Click here to login http://localhost:8992/users/login"+"\n Happy Trading...");
	           // Now send the message
	           Transport.send(messageobj);
	           System.out.println("Your email sent successfully....");
	        } 
	        catch (MessagingException exp)
	        {
	           throw new RuntimeException(exp);
	        }
	        return mentor1;
	   }

	@RequestMapping(value = "/login", method = RequestMethod.POST)
	public String login(@RequestBody Mentor login) throws ServletException {
		String jwtToken = "";
		if (login.getUsername() == null || login.getPassword() == null) {
			throw new ServletException("Please fill in username and password");
		}
		String username = login.getUsername();
		String password = login.getPassword();
		Mentor mentor = mentorService.findUser(username, password);
		if (mentor == null) {
			throw new ServletException("User email not found.");
		}
		String pwd = mentor.getPassword(); /////////// user
		if (!password.equals(pwd)) {
			throw new ServletException("Invalid login. Please check your name and password.");
		}
		jwtToken = Jwts.builder().setSubject(username).claim("roles", "mentor").setIssuedAt(new Date(0))
				.signWith(SignatureAlgorithm.HS256, "secretkey").compact();
		return jwtToken;
	}

	}
